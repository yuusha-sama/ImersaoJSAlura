var tempCelsius = prompt("Digite a temperatura no formato C°:");

var tempCelsiusNumber = parseFloat(tempCelsius); // Converter a string para número usando parseFloat

var tempKelvin = tempCelsiusNumber + 273.15;
var tempFahrenheit = (tempCelsiusNumber * 9/5) + 32;

alert("TEMPERATURA ESCOLHIDA: " + tempCelsiusNumber + " C°" + "\n\nTEMPERATURA EM K°: " + tempKelvin + "\n\nTEMPERATURA EM F°: " + tempFahrenheit);