// Pergunta ao usuário se ele deseja adicionar uma capa de filme
var vaiOuNao = prompt("Você deseja adicionar uma capa? (S/N)");
var adicionarFilme = "";

// Verifica a resposta do usuário
if (vaiOuNao == "S") {
  // Solicita que o usuário digite a URL da imagem
  adicionarFilme = prompt("Escreva a URL da imagem");
} else {
  alert('Se quiser adicionar uma URL, tente novamente depois...');
}

// Lista inicial de filmes
var listaFilmes = [
  'https://upload.wikimedia.org/wikipedia/pt/1/1b/Schoolrockposter.jpg',
  'https://static.wixstatic.com/media/da06f2_9e0748f8e4fc45eba701ee2bd5581c11~mv2.jpg/v1/fill/w_640,h_998,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/da06f2_9e0748f8e4fc45eba701ee2bd5581c11~mv2.jpg',
  'https://musicart.xboxlive.com/7/94fc5000-0000-0000-0000-000000000002/504/image.jpg',
  'https://upload.wikimedia.org/wikipedia/pt/7/76/10_Things_I_Hate_About_You.jpg',
  'https://br.web.img2.acsta.net/pictures/23/05/08/10/29/0695770.jpg'
];

// Verifica se o usuário adicionou uma capa de filme
if (adicionarFilme !== "") {
  // Adiciona a capa de filme à lista
  listaFilmes.push(adicionarFilme);
}

// Exibe as imagens dos filmes
var i = 0;

do {
  document.write('<img src=' + listaFilmes[i] + '>');
  i++;
} while (i < listaFilmes.length);