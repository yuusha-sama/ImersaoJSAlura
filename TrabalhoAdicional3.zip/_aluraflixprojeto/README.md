# _AluraFlix - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuusha-sama/pen/MWLOwqB](https://codepen.io/yuusha-sama/pen/MWLOwqB).

