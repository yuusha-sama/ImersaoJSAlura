var numSecreto = parseInt(Math.random() * 1001);

var tentativas = 0;

alert(numSecreto);

do {
  var chute = parseInt(prompt('Digite um número entre 0 e 1000'));

  if (chute > numSecreto) {
    alert("O número secreto é menor do que " + chute);
  } else if (chute < numSecreto) {
    alert("O número secreto é maior do que " + chute);
  } else {
    tentativas++; // Incrementa apenas quando o jogador acerta
    break; // Sai do laço quando o jogador acerta
  }

  tentativas++; // Incrementa em todas as tentativas

} while (chute != numSecreto);

if (chute == numSecreto) {
  alert("Parabéns! Você acertou o número secreto:" + numSecreto + " e você demorou " + tentativas + " tentativas.");
}


