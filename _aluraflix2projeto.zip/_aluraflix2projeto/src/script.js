function adicionarFilme() {
  var filmeFavorito = document.getElementById('filme').value;
  var elementoListaFilmes = document.getElementById('listaFilmes');

  // Verifica se a URL termina com uma extensão de imagem válida
  if (filmeFavorito.endsWith('.jpg') || filmeFavorito.endsWith('.png') || filmeFavorito.endsWith('.gif')) {
    
    elementoListaFilmes.innerHTML = elementoListaFilmes.innerHTML + '<img src=' + filmeFavorito + '>';
    
    
  } else {
    
    alert('URL inválida! Insira uma URL de imagem válida.');
    
    
  }
  document.getElementById('filme').value = '';
}