# _Aluraflix2  - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuusha-sama/pen/XWOzxvo](https://codepen.io/yuusha-sama/pen/XWOzxvo).

